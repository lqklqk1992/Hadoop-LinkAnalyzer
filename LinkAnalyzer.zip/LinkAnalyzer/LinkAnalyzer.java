import java.util.*;
import java.lang.StringBuilder;

import org.apache.hadoop.fs.Path;
import org.apache.hadoop.conf.*;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapred.*;
import org.apache.hadoop.util.*;

import net.htmlparser.jericho.*;
import java.io.*;

public class LinkAnalyzer
{
    public static class Map extends MapReduceBase 
	implements Mapper<LongWritable, Text, Text, IntWritable> 
    {
    	private final static IntWritable one = new IntWritable(1);
        private Text link = new Text();

        public void map(LongWritable key, Text value, 
			OutputCollector<Text, IntWritable> output, 
			Reporter reporter) throws IOException
		{
			Source source=new Source(value.toString());
			List<StartTag> list=source.getAllStartTags("a");
			for(StartTag tmp:list){
                                String str=tmp.getAttributeValue("href");
                                if(str!=null){
				    link.set(str);
				    output.collect(link, one);
                                }
			}
		}
    }
    

    public static class Reduce extends MapReduceBase 
	implements Reducer<Text, IntWritable, Text, IntWritable> 
    {
        public void reduce(Text key, Iterator<IntWritable> values, 
			   OutputCollector<Text, IntWritable> output, 
			   Reporter reporter) throws IOException 
		{
			int sum = 0;
            while (values.hasNext()) {
                sum += values.next().get();
            }
            output.collect(key, new IntWritable(sum));
        }
    }

    public static class SortMap extends MapReduceBase 
	implements Mapper<LongWritable, Text, IntWritable, Text> 
    {
        private Text link = new Text();

		public void map(LongWritable key, Text value, 
				OutputCollector<IntWritable, Text> output, 
				Reporter reporter) throws IOException 
		{
			String[] arr=value.toString().split("\t");
			IntWritable freq = new IntWritable(Integer.parseInt(arr[1]));
			link.set(arr[0]);
			output.collect(freq, link);
		}
    }

    public static class SortReduce extends MapReduceBase 
	implements Reducer<IntWritable, Text, Text, NullWritable> 
    {
    	private Text result = new Text();
		public void reduce(IntWritable key, Iterator<Text> values, 
			   OutputCollector<Text, NullWritable> output, 
			   Reporter reporter) throws IOException 
		{	
			if(key.get()>5){
				while (values.hasNext()) {
					String tmp=values.next().toString()+" "+key.toString();
					result.set(tmp);
                			output.collect(result, NullWritable.get());
            			}
			}
		}
    }

    public static void main(String[] args) throws Exception 
    {
        JobConf conf = new JobConf(LinkAnalyzer.class);
        conf.setJobName("LinkAnalyzer");

        conf.setOutputKeyClass(Text.class);
        conf.setOutputValueClass(IntWritable.class);

        conf.setMapOutputKeyClass(Text.class);
        conf.setMapOutputValueClass(IntWritable.class);

        conf.setMapperClass(Map.class);
        conf.setCombinerClass(Reduce.class);
        conf.setReducerClass(Reduce.class);

        conf.setInputFormat(TextInputFormat.class);
        conf.setOutputFormat(TextOutputFormat.class);

        FileInputFormat.setInputPaths(conf, new Path(args[0]));
        FileOutputFormat.setOutputPath(conf, new Path(args[1]+"-tmp"));

        JobClient.runJob(conf);

	JobConf Sconf = new JobConf(LinkAnalyzer.class);
        Sconf.setJobName("SortLinkAnalyzer");

        Sconf.setOutputKeyClass(Text.class);
	Sconf.setOutputKeyComparatorClass(LongWritable.DecreasingComparator.class);
        Sconf.setOutputValueClass(NullWritable.class);

        Sconf.setMapOutputKeyClass(IntWritable.class);
        Sconf.setMapOutputValueClass(Text.class);

        Sconf.setMapperClass(SortMap.class);
        Sconf.setReducerClass(SortReduce.class);

        Sconf.setInputFormat(TextInputFormat.class);
        Sconf.setOutputFormat(TextOutputFormat.class);

	Sconf.setNumMapTasks(10);
	Sconf.setNumReduceTasks(1);

        FileInputFormat.setInputPaths(Sconf, new Path(args[1]+"-tmp"));
        FileOutputFormat.setOutputPath(Sconf, new Path(args[1]));

        JobClient.runJob(Sconf);
    }
}

